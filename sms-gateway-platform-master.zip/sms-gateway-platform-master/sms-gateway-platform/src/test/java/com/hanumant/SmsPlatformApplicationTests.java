package com.hanumant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
