package com.hanumant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TelecomOperatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(TelecomOperatorApplication.class, args);
	}

}
